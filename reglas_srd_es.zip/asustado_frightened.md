---
nombre: "Asustado (Frightened)"
category: "Estados"
---


* La criatura tiene **desventaja** en las pruebas de característica y tiradas de ataque mientras la fuente de su miedo esté a la vista.
* La criatura no puede moverse voluntariamente a una posición más cercana a la fuente de su miedo.

