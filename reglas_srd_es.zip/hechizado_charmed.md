---
nombre: "Hechizado (Charmed)"
category: "Estados"
---


* La criatura no puede atacar al hechizador ni elegirlo como objetivo de habilidades dañinas o efectos mágicos.
* El hechizador tiene **ventaja** en cualquier prueba de característica para interactuar socialmente con la criatura.

