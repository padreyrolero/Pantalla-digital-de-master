---
nombre: "Acción: Destrabarse (Disengage)"
category: "Acciones"
---


Si realizas la acción de destrabarse, tu movimiento no provoca ataques de oportunidad durante el resto del turno.

