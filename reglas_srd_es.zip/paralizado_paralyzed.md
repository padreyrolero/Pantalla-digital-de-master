---
nombre: "Paralizado (Paralyzed)"
category: "Estados"
---


* La criatura está **incapacitada** (no puede realizar acciones ni reacciones) y no puede moverse ni hablar.
* La criatura falla automáticamente las tiradas de salvación de **Fuerza** y **Destreza**.
* Las tiradas de ataque contra la criatura tienen **ventaja**.
* Cualquier ataque que impacte a la criatura es un **crítico** si el atacante está a 5 pies o menos de ella.

