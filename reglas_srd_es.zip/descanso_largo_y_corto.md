---
nombre: "Descanso Largo y Corto"
category: "Reglas"
---


**Descanso Corto (mínimo 1 hora):**
* Puedes gastar uno o más **Dados de Golpe** para recuperar vida. Por cada dado gastado, tira el dado y suma tu Constitución.

**Descanso Largo (mínimo 8 horas):**
* Recuperas todos los Puntos de Golpe perdidos.
* Recuperas la mitad de tus Dados de Golpe máximos.
* No puedes beneficiarte de más de un descanso largo en un periodo de 24 horas.

