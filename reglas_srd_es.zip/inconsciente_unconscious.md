---
nombre: "Inconsciente (Unconscious)"
category: "Estados"
---


* La criatura está **incapacitada**, no puede moverse ni hablar y no es consciente de su entorno.
* La criatura deja caer cualquier cosa que estuviera sujetando y queda **derribada**.
* La criatura falla automáticamente las tiradas de salvación de **Fuerza** y **Destreza**.
* Las tiradas de ataque contra la criatura tienen **ventaja**.
* Cualquier ataque que impacte a la criatura es un **crítico** si el atacante está a 5 pies o menos de ella.

