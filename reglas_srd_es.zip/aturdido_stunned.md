---
nombre: "Aturdido (Stunned)"
category: "Estados"
---


* La criatura está **incapacitada** (no puede realizar acciones ni reacciones), no puede moverse y solo puede hablar balbuceando.
* La criatura falla automáticamente las tiradas de salvación de **Fuerza** y **Destreza**.
* Las tiradas de ataque contra la criatura tienen **ventaja**.

