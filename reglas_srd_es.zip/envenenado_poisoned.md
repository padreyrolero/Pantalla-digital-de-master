---
nombre: "Envenenado (Poisoned)"
category: "Estados"
---


* La criatura tiene **desventaja** en tiradas de ataque y pruebas de característica.

