---
nombre: "Acción: Buscar (Search)"
category: "Acciones"
---


Dedicas tu atención a encontrar algo. Dependiendo de la naturaleza de tu búsqueda, el DM podría pedirte una prueba de **Sabiduría (Percepción)** o **Inteligencia (Investigación)**.

