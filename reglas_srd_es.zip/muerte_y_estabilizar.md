---
nombre: "Muerte y Estabilizar"
category: "Reglas"
---


**Tiradas de Salvación de Muerte:**
Empiezas tu turno con 0 PV. Tira 1d20.
* **10 o más:** Éxito. (3 éxitos = Estabilizado).
* **9 o menos:** Fallo. (3 fallos = Muerto).
* **1:** Cuenta como 2 fallos.
* **20:** Recuperas 1 PV y te vuelves consciente.

**Daño a 0 PV:**
Si recibes daño estando a 0 PV, sufres un fallo de muerte. Si es un crítico, sufres 2 fallos. Si el daño iguala o supera tus PV máximos, mueres instantáneamente.

**Estabilizar:**
Puedes usar tu acción para administrar primeros auxilios a una criatura inconsciente. Requiere prueba de **Sabiduría (Medicina) CD 10**.

