---
nombre: "Acción: Preparar (Ready)"
category: "Acciones"
---


Te permite actuar más tarde en la ronda usando tu **Reacción**.

1. Decides qué circunstancia activará tu reacción.
2. Eliges la acción que realizarás (o moverte hasta tu velocidad) cuando ocurra el desencadenante.

*Ejemplo:* "Si el goblin se acerca a esa puerta, tiraré de la palanca".

