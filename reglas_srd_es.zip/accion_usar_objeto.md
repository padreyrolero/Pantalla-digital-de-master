---
nombre: "Acción: Usar Objeto"
category: "Acciones"
---


Normalmente interactúas con un objeto gratis (como desenvainar una espada). Si quieres interactuar con un segundo objeto o usar un objeto que requiera una acción específica (como beber una poción o usar un kit de sanador), usas esta acción.

