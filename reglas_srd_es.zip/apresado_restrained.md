---
nombre: "Apresado (Restrained)"
category: "Estados"
---


* La velocidad de la criatura se convierte en **0**, y no puede beneficiarse de ningún bonificador a su velocidad.
* Las tiradas de ataque contra la criatura tienen **ventaja**.
* Las tiradas de ataque de la criatura tienen **desventaja**.
* La criatura tiene **desventaja** en las tiradas de salvación de **Destreza**.

