---
nombre: "Ensordecido (Deafened)"
category: "Estados"
---


* La criatura no puede oír y falla automáticamente cualquier prueba de característica que requiera oír.

