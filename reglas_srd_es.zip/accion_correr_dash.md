---
nombre: "Acción: Correr (Dash)"
category: "Acciones"
---


Ganas movimiento adicional para el turno actual. El aumento es igual a tu velocidad, después de aplicar cualquier modificador. 

Con una velocidad de 30 pies, por ejemplo, puedes moverte hasta 60 pies en tu turno si corres.

