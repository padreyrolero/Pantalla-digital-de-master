---
nombre: "Incapacitado (Incapacitated)"
category: "Estados"
---


* La criatura no puede realizar acciones ni reacciones.

