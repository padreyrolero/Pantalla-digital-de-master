---
nombre: "Acción: Lanzar un Conjuro"
category: "Acciones"
---


Cada conjuro tiene un tiempo de lanzamiento, que especifica si el lanzador debe usar una acción, una reacción, minutos o incluso horas para lanzar el conjuro. 

La mayoría de los conjuros tienen un tiempo de lanzamiento de 1 acción.

