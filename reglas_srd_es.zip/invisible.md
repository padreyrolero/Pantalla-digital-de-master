---
nombre: "Invisible"
category: "Estados"
---


* La criatura es imposible de ver sin la ayuda de magia o un sentido especial. A efectos de esconderse, se considera que la criatura está en un área muy oscura.
* La ubicación de la criatura puede ser detectada por cualquier ruido que haga o por las huellas que deje.
* Las tiradas de ataque contra la criatura tienen **desventaja**.
* Las tiradas de ataque hechas por la criatura tienen **ventaja**.

