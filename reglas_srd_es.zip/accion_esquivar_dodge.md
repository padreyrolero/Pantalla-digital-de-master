---
nombre: "Acción: Esquivar (Dodge)"
category: "Acciones"
---


Hasta el comienzo de tu siguiente turno, cualquier tirada de ataque que se haga contra ti tiene **desventaja** si puedes ver al atacante.
Además, tienes **ventaja** en las tiradas de salvación de **Destreza**. 

Pierdes este beneficio si quedas incapacitado o si tu velocidad baja a 0.

