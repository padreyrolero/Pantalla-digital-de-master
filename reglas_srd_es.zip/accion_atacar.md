---
nombre: "Acción: Atacar"
category: "Acciones"
---


Con esta acción realizas un ataque cuerpo a cuerpo o a distancia.

Algunos rasgos, como el *Ataque Extra* del guerrero, te permiten hacer más de un ataque con esta acción. 

Puedes sustituir un ataque por un intento de **Agarre** o un **Empujón**.

