---
nombre: "Terreno Difícil"
category: "Reglas"
---


Cada pie de movimiento en terreno difícil cuesta **1 pie extra**. Esta regla es cierta incluso si múltiples cosas en un espacio cuentan como terreno difícil.

Muebles bajos, escombros, maleza, escaleras empinadas, nieve y ciénagas som ejemplos de terreno difícil. El espacio de otra criatura, sea hostil o no, también cuenta como terreno difícil.

