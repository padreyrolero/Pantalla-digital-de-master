---
nombre: "Lanzamiento: Componentes"
category: "Magia"
---


**V - Verbal:** Requiere entonar sonidos místicos. No puedes hacerlo si estás amordazado o en una zona de silencio.

**S - Somático:** Requiere gestos con las manos. Necesitas al menos una mano libre.

**M - Material:** Requiere objetos específicos. Puedes usar una bolsa de componentes o un canalizador arcano en lugar de los materiales específicos, a menos que se indique un coste en oro.

