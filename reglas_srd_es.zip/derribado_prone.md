---
nombre: "Derribado (Prone)"
category: "Estados"
---


* La única opción de movimiento que tiene la criatura es gatear, a menos que se levante y finalice así la condición.
* La criatura tiene **desventaja** en tiradas de ataque.
* Las tiradas de ataque contra la criatura tienen **ventaja** si el atacante está a 5 pies o menos. De lo contrario, tienen **desventaja**.

