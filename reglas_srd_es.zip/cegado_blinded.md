---
nombre: "Cegado (Blinded)"
category: "Estados"
---


* La criatura no puede ver y falla automáticamente cualquier prueba de característica que requiera ver.
* Las tiradas de ataque contra la criatura tienen **ventaja**.
* Las tiradas de ataque de la criatura tienen **desventaja**.

