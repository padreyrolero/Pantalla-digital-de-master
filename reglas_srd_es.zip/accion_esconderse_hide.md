---
nombre: "Acción: Esconderse (Hide)"
category: "Acciones"
---


Realizas una prueba de **Destreza (Sigilo)** para intentar ocultarte. Si tienes éxito, ganas los beneficios de no ser visto (ver reglas de Atacantes no Vistos).

