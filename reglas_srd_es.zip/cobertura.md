---
nombre: "Cobertura"
category: "Reglas"
---


Los muros, árboles, criaturas y otros obstáculos pueden proporcionar cobertura durante el combate, haciendo que un objetivo sea más difícil de dañar.

| Cobertura | Efecto |
|---|---|
| **Media (1/2)** | +2 a la CA y salvaciones de Destreza. (Muebles bajos, criaturas, troncos delgados). |
| **Tres Cuartos (3/4)** | +5 a la CA y salvaciones de Destreza. (Rastris, troncos gruesos, esquinas de muros). |
| **Total** | No puede ser objetivo directo de un ataque o conjuro. |

