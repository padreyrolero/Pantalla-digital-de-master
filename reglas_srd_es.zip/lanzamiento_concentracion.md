---
nombre: "Lanzamiento: Concentración"
category: "Magia"
---


Algunos conjuros requieren que mantengas la concentración. Si pierdes la concentración, el conjuro termina.

**Pierdes la concentración si:**
1. Lanzas otro conjuro que requiere concentración.
2. Recibes daño. Debes superar una salvación de **Constitución**. La CD es **10** o **la mitad del daño recibido** (lo que sea mayor).
3. Quedas incapacitado o mueres.

