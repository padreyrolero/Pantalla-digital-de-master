---
nombre: "Petrificado (Petrified)"
category: "Estados"
---


* La criatura, junto con cualquier objeto no mágico que vista o porte, se transforma en una sustancia sólida inanimada (generalmente piedra). Su peso se multiplica por diez y deja de envejecer.
* La criatura está **incapacitada** (no puede realizar acciones ni reacciones), no puede moverse ni hablar y no es consciente de su entorno.
* Las tiradas de ataque contra la criatura tienen **ventaja**.
* La criatura falla automáticamente las tiradas de salvación de **Fuerza** y **Destreza**.
* La criatura tiene **resistencia** a todo el daño.
* La criatura es inmune al veneno y a la enfermedad, aunque si ya sufría alguna, queda suspendida, no neutralizada.

