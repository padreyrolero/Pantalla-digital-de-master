---
nombre: "Acción: Ayudar (Help)"
category: "Acciones"
---


Puedes prestar tu ayuda a otra criatura para completar una tarea. La criatura a la que ayudas gana **ventaja** en la siguiente prueba de característica que haga para completar la tarea.

Alternativamente, puedes ayudar a una criatura aliada a atacar a otra criatura que esté a 5 pies de ti. La primera tirada de ataque de tu aliado tiene **ventaja**.

