---
nombre: "Agarrado (Grappled)"
category: "Estados"
---


* La velocidad de la criatura se convierte en **0**, y no puede beneficiarse de ningún bonificador a su velocidad.
* La condición finaliza si quien agarra queda incapacitado.
* La condición finaliza si un efecto saca a la criatura agarrada del alcance de quien la agarra o del efecto que la agarra (como cuando una criatura es arrojada por el conjuro *onda atronadora*).

