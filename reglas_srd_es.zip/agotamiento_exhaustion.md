---
nombre: "Agotamiento (Exhaustion)"
category: "Estados"
---


El agotamiento se mide en 6 niveles. Un efecto puede darte uno o más niveles.

| Nivel | Efecto |
|---|---|
| 1 | Desventaja en pruebas de característica |
| 2 | Velocidad reducida a la mitad |
| 3 | Desventaja en ataques y tiradas de salvación |
| 4 | Puntos de golpe máximos reducidos a la mitad |
| 5 | Velocidad reducida a 0 |
| 6 | Muerte |

* Si tienes agotamiento, descansar largas horas reduce tu nivel de agotamiento en 1, siempre que hayas comido y bebido.

